#ifndef __STM32F10X_CONF_H
#define __STM32F10X_CONF_H

/* STM32 Standard Peripheral Library */

#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "misc.h"

/* Enable parameter assertion */
#ifdef USE_FULL_ASSERT

#define assert_param(expr) \
    ((expr) ? (void)0 : assert_failed((uint8_t *)__FILE__, __LINE__))

void assert_failed(uint8_t *file, uint32_t line);

#else

#define assert_param(expr) ((void)0)

#endif

#endif