.syntax unified
.cpu cortex-m3
.thumb

.global g_pfnVectors
.global Reset_Handler
.global Default_Handler

.extern _estack
.extern _sidata
.extern _sdata
.extern _edata
.extern _sbss
.extern _ebss

.extern SystemInit
.extern main

/* FreeRTOS interrupt handlers */
.extern vPortSVCHandler
.extern xPortPendSVHandler
.extern xPortSysTickHandler

/* =========================================================
   RESET HANDLER
   - Copy .data from FLASH to RAM
   - Clear .bss
   - Initialize system clock
   - Call main()
   ========================================================= */

.section .text.Reset_Handler, "ax", %progbits
.align 2
.thumb_func

Reset_Handler:
    /* Copy initialized data from FLASH to RAM */
    ldr r0, =_sdata
    ldr r1, =_edata
    ldr r2, =_sidata

CopyData:
    cmp r0, r1
    bcs ClearBSS

    ldr r3, [r2]
    str r3, [r0]

    adds r0, r0, #4
    adds r2, r2, #4
    b CopyData

    /* Clear the .bss section */
ClearBSS:
    ldr r0, =_sbss
    ldr r1, =_ebss
    movs r2, #0

ClearBSSLoop:
    cmp r0, r1
    bcs InitSystem

    str r2, [r0]
    adds r0, r0, #4
    b ClearBSSLoop

    /* Initialize system clock */
InitSystem:
    bl SystemInit

    /* Enter main */
    bl main

    /* main() should never return */
InfiniteLoop:
    b InfiniteLoop

.size Reset_Handler, . - Reset_Handler


/* =========================================================
   DEFAULT HANDLER
   ========================================================= */

.section .text.Default_Handler, "ax", %progbits
.align 2
.thumb_func

Default_Handler:
    b Default_Handler

.size Default_Handler, . - Default_Handler


/* =========================================================
   STM32F103x8/xB VECTOR TABLE
   Medium-density devices
   ========================================================= */

.section .isr_vector, "a", %progbits
.align 2

.type g_pfnVectors, %object

g_pfnVectors:
    /* Cortex-M3 core vectors */
    .word _estack
    .word Reset_Handler
    .word NMI_Handler
    .word HardFault_Handler
    .word MemManage_Handler
    .word BusFault_Handler
    .word UsageFault_Handler
    .word 0
    .word 0
    .word 0
    .word 0

        /* FreeRTOS interrupt handlers */
    .word SVC_Handler
    .word DebugMon_Handler
    .word 0
    .word PendSV_Handler
    .word SysTick_Handler

    /* STM32F103 medium-density peripheral vectors */
    .word WWDG_IRQHandler
    .word PVD_IRQHandler
    .word TAMPER_IRQHandler
    .word RTC_IRQHandler
    .word FLASH_IRQHandler
    .word RCC_IRQHandler
    .word EXTI0_IRQHandler
    .word EXTI1_IRQHandler
    .word EXTI2_IRQHandler
    .word EXTI3_IRQHandler
    .word EXTI4_IRQHandler
    .word DMA1_Channel1_IRQHandler
    .word DMA1_Channel2_IRQHandler
    .word DMA1_Channel3_IRQHandler
    .word DMA1_Channel4_IRQHandler
    .word DMA1_Channel5_IRQHandler
    .word DMA1_Channel6_IRQHandler
    .word DMA1_Channel7_IRQHandler
    .word ADC1_2_IRQHandler
    .word USB_HP_CAN1_TX_IRQHandler
    .word USB_LP_CAN1_RX0_IRQHandler
    .word CAN1_RX1_IRQHandler
    .word CAN1_SCE_IRQHandler
    .word EXTI9_5_IRQHandler
    .word TIM1_BRK_IRQHandler
    .word TIM1_UP_IRQHandler
    .word TIM1_TRG_COM_IRQHandler
    .word TIM1_CC_IRQHandler
    .word TIM2_IRQHandler
    .word TIM3_IRQHandler
    .word TIM4_IRQHandler
    .word I2C1_EV_IRQHandler
    .word I2C1_ER_IRQHandler
    .word I2C2_EV_IRQHandler
    .word I2C2_ER_IRQHandler
    .word SPI1_IRQHandler
    .word SPI2_IRQHandler
    .word USART1_IRQHandler
    .word USART2_IRQHandler
    .word USART3_IRQHandler
    .word EXTI15_10_IRQHandler
    .word RTCAlarm_IRQHandler
    .word USBWakeUp_IRQHandler

    /* Reserved vectors and boot from RAM */
    .word 0
    .word 0
    .word 0
    .word 0
    .word 0
    .word 0
    .word 0
    .word 0
    .word BootRAM

.size g_pfnVectors, . - g_pfnVectors


/* =========================================================
   WEAK DEFAULT INTERRUPT HANDLERS
   ========================================================= */

.equ BootRAM, 0xF108F85F

.macro WEAK_DEFAULT handler
    .weak \handler
    .thumb_set \handler, Default_Handler
.endm

WEAK_DEFAULT NMI_Handler
WEAK_DEFAULT HardFault_Handler
WEAK_DEFAULT MemManage_Handler
WEAK_DEFAULT BusFault_Handler
WEAK_DEFAULT UsageFault_Handler
WEAK_DEFAULT DebugMon_Handler

WEAK_DEFAULT WWDG_IRQHandler
WEAK_DEFAULT PVD_IRQHandler
WEAK_DEFAULT TAMPER_IRQHandler
WEAK_DEFAULT RTC_IRQHandler
WEAK_DEFAULT FLASH_IRQHandler
WEAK_DEFAULT RCC_IRQHandler
WEAK_DEFAULT EXTI0_IRQHandler
WEAK_DEFAULT EXTI1_IRQHandler
WEAK_DEFAULT EXTI2_IRQHandler
WEAK_DEFAULT EXTI3_IRQHandler
WEAK_DEFAULT EXTI4_IRQHandler
WEAK_DEFAULT DMA1_Channel1_IRQHandler
WEAK_DEFAULT DMA1_Channel2_IRQHandler
WEAK_DEFAULT DMA1_Channel3_IRQHandler
WEAK_DEFAULT DMA1_Channel4_IRQHandler
WEAK_DEFAULT DMA1_Channel5_IRQHandler
WEAK_DEFAULT DMA1_Channel6_IRQHandler
WEAK_DEFAULT DMA1_Channel7_IRQHandler
WEAK_DEFAULT ADC1_2_IRQHandler
WEAK_DEFAULT USB_HP_CAN1_TX_IRQHandler
WEAK_DEFAULT USB_LP_CAN1_RX0_IRQHandler
WEAK_DEFAULT CAN1_RX1_IRQHandler
WEAK_DEFAULT CAN1_SCE_IRQHandler
WEAK_DEFAULT EXTI9_5_IRQHandler
WEAK_DEFAULT TIM1_BRK_IRQHandler
WEAK_DEFAULT TIM1_UP_IRQHandler
WEAK_DEFAULT TIM1_TRG_COM_IRQHandler
WEAK_DEFAULT TIM1_CC_IRQHandler
WEAK_DEFAULT TIM2_IRQHandler
WEAK_DEFAULT TIM3_IRQHandler
WEAK_DEFAULT TIM4_IRQHandler
WEAK_DEFAULT I2C1_EV_IRQHandler
WEAK_DEFAULT I2C1_ER_IRQHandler
WEAK_DEFAULT I2C2_EV_IRQHandler
WEAK_DEFAULT I2C2_ER_IRQHandler
WEAK_DEFAULT SPI1_IRQHandler
WEAK_DEFAULT SPI2_IRQHandler
WEAK_DEFAULT USART1_IRQHandler
WEAK_DEFAULT USART2_IRQHandler
WEAK_DEFAULT USART3_IRQHandler
WEAK_DEFAULT EXTI15_10_IRQHandler
WEAK_DEFAULT RTCAlarm_IRQHandler
WEAK_DEFAULT USBWakeUp_IRQHandler